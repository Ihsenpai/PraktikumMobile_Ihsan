- **Nama** : Muhammad Nabil Putra Monti
- **NIM** : H1D023063
- **Shift KRS** : G
- **Shift Discord** : B
<img width="564" height="980" alt="image" src="https://github.com/user-attachments/assets/47a4907c-d4d8-4fb2-8469-938f38801514" />


